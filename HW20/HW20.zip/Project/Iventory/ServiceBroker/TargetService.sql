﻿CREATE SERVICE [//WWI/SB/TargetService]
	ON QUEUE [dbo].[TargetQueueWWI]
	(
		[//WWI/SB/Contract]
	)