﻿CREATE CONTRACT [//WWI/SB/Contract]
(
	[//WWI/SB/RequestMessage] SENT BY INITIATOR,
	[//WWI/SB/ReplyMessage] SENT BY TARGET
);