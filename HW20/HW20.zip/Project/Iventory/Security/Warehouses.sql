﻿CREATE SCHEMA [Warehouses]
